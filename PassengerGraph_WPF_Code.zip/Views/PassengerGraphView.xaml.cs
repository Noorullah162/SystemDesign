using System.Windows;
using System.Windows.Controls;
using PassengerGraph.ViewModels;

namespace PassengerGraph.Views
{
    public partial class PassengerGraphView : UserControl
    {
        public PassengerGraphView()
        {
            InitializeComponent();

            // Replace this with your existing SQL connection string.
            var connectionString =
                "Server=YOUR_SERVER;Database=YOUR_DATABASE;Trusted_Connection=True;";

            DataContext = new PassengerGraphViewModel(connectionString);

            Loaded += PassengerGraphView_Loaded;
            Unloaded += PassengerGraphView_Unloaded;
        }

        private async void PassengerGraphView_Loaded(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as PassengerGraphViewModel;
            if (vm != null)
                await vm.LoadAsync();
        }

        private void PassengerGraphView_Unloaded(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as PassengerGraphViewModel;
            if (vm != null)
                vm.Dispose();
        }

        private async void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as PassengerGraphViewModel;
            if (vm != null)
                await vm.LoadAsync();
        }
    }
}

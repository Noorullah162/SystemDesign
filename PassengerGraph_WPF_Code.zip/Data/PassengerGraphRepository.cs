using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using PassengerGraph.Models;

namespace PassengerGraph.Data
{
    public class PassengerGraphRepository
    {
        private readonly string _connectionString;

        public PassengerGraphRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public async Task<List<PassengerGraphPoint>> GetPassengerGraphDataAsync(
            DateTime fromDateTime, DateTime toDateTime, int corridor, int direction,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var result = new List<PassengerGraphPoint>();

            const string sql = @"
;WITH TripData AS
(
    SELECT p.*,
        CASE WHEN LAG(p.Direction) OVER
        (
            PARTITION BY p.TrainNo, p.Corridor ORDER BY p.DDateTime
        ) <> p.Direction THEN 1 ELSE 0 END AS TripChange
    FROM PassengerCount p
    WHERE p.DDateTime >= CAST(@FromDateTime AS DATE)
      AND p.DDateTime < DATEADD(DAY, 1, CAST(@FromDateTime AS DATE))
      AND p.Corridor = @Corridor
),
NumberedTrips AS
(
    SELECT *,
        SUM(TripChange) OVER
        (
            PARTITION BY TrainNo, Corridor
            ORDER BY DDateTime ROWS UNBOUNDED PRECEDING
        ) AS TripId
    FROM TripData
),
PassengerData AS
(
    SELECT TrainNo, TripId, Direction, Corridor, DDateTime,
        CurrentStationDA, NextStationDA,
        CAST((BoogieLoadDA1 + BoogieLoadDA2 - 42590) / 65 AS INT) AS DA,
        CAST((BoogieLoadTA1 + BoogieLoadTA2 - 39980) / 65 AS INT) AS TA,
        CAST((BoogieLoadDB1 + BoogieLoadDB2 - 42590) / 65 AS INT) AS DB
    FROM NumberedTrips
    WHERE DDateTime >= @FromDateTime
      AND DDateTime < @ToDateTime
      AND Direction = @Direction
      AND CurrentStationDA <> NextStationDA
),
StationData AS
(
    SELECT p.TrainNo, p.TripId, cds.StationIndex, p.DDateTime,
        cs.StationName AS CurrentStation,
        ns.StationName AS NextStation,
        CASE WHEN p.DA < 0 THEN 0 ELSE p.DA END
        + CASE WHEN p.TA < 0 THEN 0 ELSE p.TA END
        + CASE WHEN p.DB < 0 THEN 0 ELSE p.DB END AS TotalPassenger
    FROM PassengerData p
    INNER JOIN CorridorDirectionStations cds
        ON cds.Corridor = p.Corridor
       AND cds.Direction = p.Direction
       AND cds.StationCode = p.CurrentStationDA
    INNER JOIN StationCodes cs ON cs.StationCode = p.CurrentStationDA
    INNER JOIN StationCodes ns ON ns.StationCode = p.NextStationDA
),
FinalData AS
(
    SELECT *,
        ROW_NUMBER() OVER
        (
            PARTITION BY TrainNo, TripId, StationIndex
            ORDER BY DDateTime
        ) AS rn
    FROM StationData
)
SELECT TrainNo, TripId, StationIndex, CurrentStation, NextStation,
       DDateTime, TotalPassenger
FROM FinalData
WHERE rn = 1
ORDER BY StationIndex, TrainNo;";

            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(sql, connection))
            {
                command.CommandTimeout = 120;
                command.Parameters.AddWithValue("@FromDateTime", fromDateTime);
                command.Parameters.AddWithValue("@ToDateTime", toDateTime);
                command.Parameters.AddWithValue("@Corridor", corridor);
                command.Parameters.AddWithValue("@Direction", direction);

                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

                using (var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false))
                {
                    while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
                    {
                        result.Add(new PassengerGraphPoint
                        {
                            TrainNo = reader["TrainNo"].ToString(),
                            TripId = Convert.ToInt32(reader["TripId"]),
                            StationIndex = Convert.ToInt32(reader["StationIndex"]),
                            CurrentStation = reader["CurrentStation"].ToString(),
                            NextStation = reader["NextStation"].ToString(),
                            DDateTime = Convert.ToDateTime(reader["DDateTime"]),
                            TotalPassenger = Convert.ToInt32(reader["TotalPassenger"])
                        });
                    }
                }
            }
            return result;
        }

        public async Task<List<StationAxisItem>> GetStationAxisAsync(
            int corridor, int direction,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var result = new List<StationAxisItem>();

            const string sql = @"
SELECT cds.StationIndex, sc.StationName
FROM CorridorDirectionStations cds
INNER JOIN StationCodes sc ON sc.StationCode = cds.StationCode
WHERE cds.Corridor = @Corridor
  AND cds.Direction = @Direction
ORDER BY cds.StationIndex;";

            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@Corridor", corridor);
                command.Parameters.AddWithValue("@Direction", direction);
                await connection.OpenAsync(cancellationToken).ConfigureAwait(false);

                using (var reader = await command.ExecuteReaderAsync(cancellationToken).ConfigureAwait(false))
                {
                    while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
                    {
                        result.Add(new StationAxisItem
                        {
                            StationIndex = Convert.ToInt32(reader["StationIndex"]),
                            StationName = reader["StationName"].ToString()
                        });
                    }
                }
            }
            return result;
        }
    }
}

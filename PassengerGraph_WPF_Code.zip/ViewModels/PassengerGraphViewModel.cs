using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using PassengerGraph.Data;
using PassengerGraph.Models;

namespace PassengerGraph.ViewModels
{
    public class PassengerGraphViewModel : INotifyPropertyChanged
    {
        private readonly PassengerGraphRepository _repository;
        private CancellationTokenSource _refreshCts;

        private int _corridor = 3;
        private int _direction = 1;
        private DateTime _fromDateTime = new DateTime(2026, 6, 8, 7, 0, 0);
        private DateTime _toDateTime = new DateTime(2026, 6, 8, 9, 0, 0);
        private bool _isLoading;
        private string _status = "Ready";

        public ObservableCollection<string> TrainNames { get; } =
            new ObservableCollection<string>();

        public ISeries[] Series { get; private set; } = new ISeries[0];
        public Axis[] XAxes { get; private set; } = new Axis[0];

        public Axis[] YAxes { get; } =
        {
            new Axis
            {
                Name = "Passenger Count",
                Labeler = value => value.ToString("0")
            }
        };

        public int Corridor { get { return _corridor; } set { _corridor = value; OnPropertyChanged(); } }
        public int Direction { get { return _direction; } set { _direction = value; OnPropertyChanged(); } }
        public DateTime FromDateTime { get { return _fromDateTime; } set { _fromDateTime = value; OnPropertyChanged(); } }
        public DateTime ToDateTime { get { return _toDateTime; } set { _toDateTime = value; OnPropertyChanged(); } }
        public bool IsLoading { get { return _isLoading; } private set { _isLoading = value; OnPropertyChanged(); } }
        public string Status { get { return _status; } private set { _status = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler PropertyChanged;

        public PassengerGraphViewModel(string connectionString)
        {
            _repository = new PassengerGraphRepository(connectionString);
        }

        public async Task LoadAsync()
        {
            if (IsLoading) return;

            _refreshCts?.Cancel();
            _refreshCts?.Dispose();
            _refreshCts = new CancellationTokenSource();

            IsLoading = true;
            Status = "Loading passenger data...";

            try
            {
                var token = _refreshCts.Token;

                var stationsTask = _repository.GetStationAxisAsync(Corridor, Direction, token);
                var dataTask = _repository.GetPassengerGraphDataAsync(
                    FromDateTime, ToDateTime, Corridor, Direction, token);

                await Task.WhenAll(stationsTask, dataTask);

                var stations = await stationsTask;
                var points = await dataTask;

                BuildAxis(stations);
                BuildSeries(points);

                Status = string.Format("{0} train/trip lines, {1} points loaded.",
                    Series.Length, points.Count);
            }
            catch (OperationCanceledException)
            {
                Status = "Refresh cancelled.";
            }
            catch (Exception ex)
            {
                Status = "Error: " + ex.Message;
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void BuildAxis(List<StationAxisItem> stations)
        {
            XAxes = new[]
            {
                new Axis
                {
                    Name = "Stations",
                    Labels = stations.OrderBy(x => x.StationIndex)
                                     .Select(x => x.StationName)
                                     .ToArray(),
                    LabelsRotation = 45
                }
            };
            OnPropertyChanged(nameof(XAxes));
        }

        private void BuildSeries(List<PassengerGraphPoint> points)
        {
            TrainNames.Clear();

            var groups = points.GroupBy(x => new { x.TrainNo, x.TripId })
                               .OrderBy(x => x.Key.TrainNo)
                               .ThenBy(x => x.Key.TripId)
                               .ToList();

            var series = new List<ISeries>();

            foreach (var group in groups)
            {
                var train = group.Key.TrainNo;
                var ordered = group.OrderBy(x => x.StationIndex).ToList();

                if (!TrainNames.Contains(train))
                    TrainNames.Add(train);

                // Use LiveCharts Cartesian points. StationIndex - 1 aligns
                // with the zero-based Labels array.
                var values = ordered.Select(x =>
                    new LiveChartsCore.Defaults.ObservablePoint(
                        x.StationIndex - 1,
                        x.TotalPassenger)).ToArray();

                var line = new LineSeries<LiveChartsCore.Defaults.ObservablePoint>
                {
                    Name = train,
                    Values = values,
                    GeometrySize = 7,
                    LineSmoothness = 0,
                    Fill = null
                };

                series.Add(line);
            }

            Series = series.ToArray();
            OnPropertyChanged(nameof(Series));
        }

        public void Dispose()
        {
            _refreshCts?.Cancel();
            _refreshCts?.Dispose();
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

# Passenger Graph WPF starter

## Current static test
- Corridor: 3
- Direction: 1
- Date: 2026-06-08
- Time: 07:00 to 09:00

## Put files here
Copy into the corresponding folders in your existing WPF .NET Framework 4.8.1 project:

Models/
  PassengerGraphPoint.cs
  StationAxisItem.cs

Data/
  PassengerGraphRepository.cs

ViewModels/
  PassengerGraphViewModel.cs

Views/
  PassengerGraphView.xaml
  PassengerGraphView.xaml.cs

SQL/
  PassengerGraph_Static.sql

## Before running
1. Keep your existing project namespace or change the sample namespace `PassengerGraph`.
2. Replace the connection string in `PassengerGraphView.xaml.cs` with your existing SQL Server connection string.
3. Use the same LiveCharts2 package/version already installed in your project.
4. The SQL expects:
   - PassengerCount
   - StationCodes
   - CorridorDirectionStations
5. CorridorDirectionStations should already contain your 128 mappings.

## Graph design
- X axis = StationIndex / station names.
- Y axis = TotalPassenger.
- One LineSeries = one TrainNo + TripId.
- A train that starts later has points only from that station; it is not padded with zeros.
- StationCode is never used for graph ordering.
- StationIndex controls the corridor/direction order.

## First integration
Add PassengerGraphView to the page where the Passenger Count graph should appear, or temporarily put it inside a test Window.

The ViewModel initially uses:
Corridor=3
Direction=1
From=2026-06-08 07:00
To=2026-06-08 09:00

Click Refresh to run again.

## Important LiveCharts note
LiveCharts2 APIs vary by package version. This sample uses the common LiveChartsCore + LiveChartsCore.SkiaSharpView WPF API. If your existing project uses another LiveCharts2 version, adjust only the chart-specific types/properties to match that installed version.

## Next stages
After the basic graph is working:
1. Add static Corridor/Direction UI.
2. Add From/To date/time.
3. Add 1-hour / 2-hour quick filters.
4. Add automatic refresh.
5. Detect inactive trains and hide/disable their lines.
6. Add station active/inactive behavior.
7. Add rich tooltip showing time, From station, To station and passenger value.
8. Optimize SQL/indexes for the production-size table.

DECLARE @FromDateTime DATETIME = '2026-06-08 07:00:00.000';
DECLARE @ToDateTime   DATETIME = '2026-06-08 09:00:00.000';
DECLARE @Corridor INT = 3;
DECLARE @Direction INT = 1;

;WITH TripData AS
(
    SELECT p.*,
        CASE WHEN LAG(p.Direction) OVER
        (
            PARTITION BY p.TrainNo, p.Corridor ORDER BY p.DDateTime
        ) <> p.Direction THEN 1 ELSE 0 END AS TripChange
    FROM PassengerCount p
    WHERE p.DDateTime >= CAST(@FromDateTime AS DATE)
      AND p.DDateTime < DATEADD(DAY, 1, CAST(@FromDateTime AS DATE))
      AND p.Corridor = @Corridor
),
NumberedTrips AS
(
    SELECT *,
        SUM(TripChange) OVER
        (
            PARTITION BY TrainNo, Corridor
            ORDER BY DDateTime ROWS UNBOUNDED PRECEDING
        ) AS TripId
    FROM TripData
),
PassengerData AS
(
    SELECT TrainNo, TripId, Direction, Corridor, DDateTime,
        CurrentStationDA, NextStationDA,
        CAST((BoogieLoadDA1 + BoogieLoadDA2 - 42590) / 65 AS INT) AS DA,
        CAST((BoogieLoadTA1 + BoogieLoadTA2 - 39980) / 65 AS INT) AS TA,
        CAST((BoogieLoadDB1 + BoogieLoadDB2 - 42590) / 65 AS INT) AS DB
    FROM NumberedTrips
    WHERE DDateTime >= @FromDateTime
      AND DDateTime < @ToDateTime
      AND Direction = @Direction
      AND CurrentStationDA <> NextStationDA
),
StationData AS
(
    SELECT p.TrainNo, p.TripId, cds.StationIndex, p.DDateTime,
        cs.StationName AS CurrentStation,
        ns.StationName AS NextStation,
        CASE WHEN p.DA < 0 THEN 0 ELSE p.DA END
        + CASE WHEN p.TA < 0 THEN 0 ELSE p.TA END
        + CASE WHEN p.DB < 0 THEN 0 ELSE p.DB END AS TotalPassenger
    FROM PassengerData p
    INNER JOIN CorridorDirectionStations cds
        ON cds.Corridor = p.Corridor
       AND cds.Direction = p.Direction
       AND cds.StationCode = p.CurrentStationDA
    INNER JOIN StationCodes cs ON cs.StationCode = p.CurrentStationDA
    INNER JOIN StationCodes ns ON ns.StationCode = p.NextStationDA
),
FinalData AS
(
    SELECT *,
        ROW_NUMBER() OVER
        (
            PARTITION BY TrainNo, TripId, StationIndex
            ORDER BY DDateTime
        ) AS rn
    FROM StationData
)
SELECT TrainNo, TripId, StationIndex, CurrentStation, NextStation,
       DDateTime, TotalPassenger
FROM FinalData
WHERE rn = 1
ORDER BY StationIndex, TrainNo;

WITH TrainData AS 
(   SELECT 
DISTINCT t.Time,  
CASE When (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 <= 0 
THEN 0 ELSE  (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 End AS DA,  
CASE when (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 <= 0 THEN 0 Else  
(IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 End AS TA,  
CASE when (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 <= 0 
THEN 0 Else (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 End  AS DB,  
t.HeadControl_DA, t.Speed_DA, sc_current_da.stationFullName AS CurrentStation, sc_next_da.stationFullName AS NextStation 
FROM TS053 t  
INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode  
INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode  
WHERE t.CurrentStation_DA != '' and  t.time Between '2026-06-08 06:00:25.0' AND '2026-06-08 06:13:40.0'  GROUP by t.CurrentStation_DA ) 
SELECT    
row_number() OVER (ORDER BY Time) AS RowNumber, CurrentStation,  
CASE  WHEN CurrentStation IS NOT NULL AND LENGTH(CurrentStation) > 0 THEN Time || ' ' || CurrentStation || ' - ' || NextStation  ELSE ' '
END AS Description,  
DA, TA, DB, DA + TA + DB as Total  From TrainData  where CurrentStation != NextStation  Order BY Time;
WITH TripData AS (
    SELECT
        no,           -- Auto-increment column
        time,
        HeadControl_DA,
        -- Detect when direction changes
        CASE 
            WHEN HeadControl_DA != LAG(HeadControl_DA) OVER (ORDER BY time) 
            THEN 1 ELSE 0 
        END AS trip_change
    FROM TS001
),
NumberedTrips AS (
    SELECT 
        *,
        -- Assign a unique trip number based on direction change
        SUM(trip_change) OVER (ORDER BY time) AS trip_id
    FROM TripData
)
SELECT
    CASE WHEN HeadControl_DA = 1 THEN 'Upline' ELSE 'Downline' END AS Direction,
    MIN(time) AS from_datetime,
    MAX(time) AS to_datetime
FROM NumberedTrips
GROUP BY HeadControl_DA, trip_id
ORDER BY from_datetime;

WITH TripData AS 
( SELECT no,  time,  HeadControl_DA, CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 WHERE time >= '2025-08-12 00:00:00' and time <= '2025-08-12 23:59:59'), 
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT 
	CASE WHEN HeadControl_DA = 1 THEN 'Upline' 
		ELSE 'Downline' END AS Direction,  
	MIN(time) AS From_Datetime, MAX(time) AS To_Datetime 
FROM NumberedTrips GROUP BY HeadControl_DA, trip_id ORDER BY From_Datetime; 


WITH TripData AS 
( SELECT no,  time,  HeadControl_DA, CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 
WHERE time >= '2025-08-12 00:00:00' and time <= '2025-08-12 23:59:59'), 
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT 
	CASE WHEN HeadControl_DA = 1 THEN 'Upline' 
		ELSE 'Downline' END AS Direction,  
	MIN(time) AS From_Datetime, MAX(time) AS To_Datetime 
FROM NumberedTrips GROUP BY HeadControl_DA, trip_id HAVING HeadControl_DA = 1 ORDER BY From_Datetime; 

WITH TripData AS 
( SELECT no,  time,  HeadControl_DA, CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 WHERE time >= '2025-08-12 00:00:00' and time <= '2025-08-12 23:59:59'), 
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT 
	CASE WHEN HeadControl_DA = 1 THEN 'Upline' 
		ELSE 'Downline' END AS Direction,  
	MIN(time) AS From_Datetime, MAX(time) AS To_Datetime 
FROM NumberedTrips GROUP BY HeadControl_DA, trip_id ORDER BY From_Datetime; 


WITH TripData AS 
( SELECT no,  time,  HeadControl_DA, CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 WHERE time >= '2025-08-12 00:00:00' AND time <= '2025-08-12 23:59:59'  ), 
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT CASE WHEN HeadControl_DA = 1 THEN 'Upline' ELSE 'Downline' END AS Direction,  MIN(time) AS FromDateTime, MAX(time) AS ToDateTime 
FROM NumberedTrips  GROUP BY HeadControl_DA, trip_id Having Count(HeadControl_DA) >= 22  ORDER BY FromDateTime;

-- UI Trip Summary Data
WITH TripData AS 
( SELECT no,  time,  HeadControl_DA, 
CASE WHEN HeadControl_DA != LAG(HeadControl_DA) 
OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 
WHERE time >= '2025-08-12 00:00:00' AND time <= '2025-08-12 23:59:59'  ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT CASE WHEN HeadControl_DA = 1 THEN 'Upline' ELSE 'Downline' END AS Direction,  
MIN(time) AS FromDateTime, MAX(time) AS ToDateTime 
FROM NumberedTrips  GROUP BY HeadControl_DA, trip_id Having Count(HeadControl_DA) >= 22  ORDER BY FromDateTime;


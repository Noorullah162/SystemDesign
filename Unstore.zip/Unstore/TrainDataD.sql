WITH TrainData AS (
    SELECT
        DISTINCT t.Time,
		CASE
			WHEN ( (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65) < 0
				Then 0
			ELSE
				(IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65
		END	AS DA,
		CASE
			WHEN ((IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65) < 0
				THEN 0
			ELSE 
				(IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65
		END	AS TA,
        CASE 
			WHEN ((IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65) < 0
			THEN 0
			ELSE 
				(IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65
		END	AS DB,
        t.HeadControl_DA,
        t.Speed_DA,
		sc_current_da.stationFullName AS CurrentStation,
		t.CurrentStation_DA as currentStationCode,
        sc_next_da.stationFullName AS NextStation
    FROM TS005 t
    INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode
	INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode
    WHERE t.CurrentStation_DA != "" and 
	t.Time BETWEEN '2025-08-12 07:36:43' and '2025-08-12 08:25:58'
	GROUP by t.CurrentStation_DA
)
SELECT
    row_number() OVER (ORDER BY Time) AS RowNumber,
	-- currentStationCode,
    CurrentStation,
    CONCAT(Time, ' ', CurrentStation, ' - ', NextStation) AS Description,
    DA,
    TA,
    DB,
    DA + TA + DB as Total,
	NTILE(3) OVER (ORDER BY DA+TA+DB ) - 1 AS Status
FROM TrainData
where CurrentStation != NextStation
ORDER BY Time;
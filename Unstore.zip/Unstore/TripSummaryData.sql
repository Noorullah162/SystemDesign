WITH TripData AS ( 
SELECT no,  time,  
HeadControl_DA, 
Direction,
Corridor,
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS022 WHERE  time >= '2026-06-08 06:00:00' AND time <= '2026-06-08 23:00:00' ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT "TS022" as Train, Direction, Corridor,
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips 
 GROUP BY Corridor, trip_id HAVING Direction = '0' ORDER BY From_Datetime; 
 
 -- upline downline trips summary 
 WITH TripData AS ( 
SELECT no,  time,  
HeadControl_DA, 
Direction,
Corridor,
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS022 WHERE  time >= '2026-06-08 06:00:00' AND time <= '2026-06-08 23:00:00' ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT "TS022" as Train, Direction, Corridor,
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips 
 GROUP BY Corridor, trip_id ORDER BY From_Datetime; 
 
WITH TripData AS ( 
SELECT no,  time,  
HeadControl_DA, 
Direction,
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS001 WHERE DATE(time) = '2026-06-08' ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT CASE WHEN Direction = 0 THEN 'Upline' ELSE 'Downline' END AS Direction1,  
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips 
 GROUP BY trip_id ORDER BY From_Datetime; 
 
 
 WITH TripData AS 
 ( SELECT  no,  time,  
 HeadControl_DA, 
 CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
 FROM TS001 WHERE DATE(time) = '2026-06-08' ), 
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
 SELECT
 CASE WHEN HeadControl_DA = 1 THEN 'Upline' ELSE 'Downline' END AS Direction1,  
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime
 FROM NumberedTrips GROUP BY HeadControl_DA, trip_id ORDER BY From_Datetime; 
 
 SELECT DISTINCT name FROM sqlite_master WHERE type='table' AND name LIKE 'TS%' order by name;
 
 
 -- 20260708 modified QUERY
 WITH TripData AS ( 
SELECT no,  time,  
HeadControl_DA, 
Direction,
Corridor,
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS022 WHERE  time >= '2026-06-08 06:00:00' AND time <= '2026-06-08 23:00:00' ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT "TS022" as Train, Direction, Corridor,
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips 
 GROUP BY Corridor, trip_id HAVING Direction = '0' ORDER BY From_Datetime; 
 
 -- upline downline trips summary 
 WITH TripData AS ( 
SELECT no,  time,  
HeadControl_DA, 
Direction,
Corridor,
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS022 WHERE  time >= '2026-06-08 06:00:00' AND time <= '2026-06-08 23:00:00' ),
 NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT "TS022" as Train, Direction, Corridor,
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips 
 GROUP BY Corridor, trip_id ORDER BY From_Datetime; 
 
 
 WITH TripData AS 
(  SELECT no,  time,  Direction, Corridor, 
CASE WHEN Direction != LAG(Direction) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change  
FROM TS007 WHERE Date(time) >= '2026-06-08'  AND Date(time) <= '2026-06-08' ), 
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData)  
SELECT 'TS007' AS Train, 
Direction, Corridor,  MIN(time) AS From_Datetime, MAX(time) AS To_Datetime 
FROM NumberedTrips  GROUP BY Corridor, trip_id 
ORDER BY From_Datetime;
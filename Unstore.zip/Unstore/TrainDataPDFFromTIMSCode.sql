WITH TrainData AS ( 
 SELECT DISTINCT t.Time, 
 CASE 
	When (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 <=0
	Then 0
	else (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65  
  END AS DA,
  CASE
	When (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 <= 0
	Then 0
	Else (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 
  End AS TA,
  CASE
	When (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 <=0
	Then 0	
	Else (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 
  END AS DB, 
  t.HeadControl_DA as HeadControl, t.Speed_DA, sc_current_da.stationFullName AS CurrentStation, sc_next_da.stationFullName AS NextStation
  FROM TS003 as t
  INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode
  INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode 
  WHERE t.CurrentStation_DA != '' and  t.time Between '2024-12-14 08:11:17.5' AND '2025-06-07 08:07:47.5'
  GROUP by t.CurrentStation_DA
  )
  SELECT    row_number() OVER (ORDER BY Time) AS RowNumber, CurrentStation, 
  CASE
  WHEN CurrentStation IS NOT NULL AND LENGTH(CurrentStation) > 0 THEN case when HeadControl = '1' Then 'Up' else 'Down' end || ' - ' || CurrentStation || '-' || NextStation 
   ELSE ' '
   END AS Description,
    DA, TA, DB, DA + TA + DB as Total
	From TrainData
	 where CurrentStation != NextStation
	  Order BY Time;
	  
	  
	  
WITH TrainData AS 
(   
	SELECT DISTINCT t.Time,  
	CASE When (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 <= 0 
	THEN 0 ELSE  (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 End AS DA,  
	CASE when (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 <= 0 
	THEN 0 Else  (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 End AS TA,  
	CASE when (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 <= 0 
	THEN 0 Else (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 End  AS DB,  
	t.HeadControl_DA, t.Speed_DA, sc_current_da.stationFullName AS CurrentStation, sc_next_da.stationFullName AS NextStation 
	FROM   TS003 as t  
	INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON 
	t.CurrentStation_DA = sc_current_da.stationCode  INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON 
	t.NextStation_DA = sc_next_da.stationCode  
	WHERE t.CurrentStation_DA != '' and  t.time Between '2025-08-12 09:57:54.5' AND '2025-08-12 10:41:18.0'  GROUP by t.CurrentStation_DA ) 
	SELECT    row_number() OVER (ORDER BY Time) AS RowNumber, CurrentStation,  
	CASE  WHEN CurrentStation IS NOT NULL AND LENGTH(CurrentStation) > 0 THEN Time || ' ' || CurrentStation || ' - ' || NextStation  ELSE ' ' 
	END AS Description,  DA, TA, DB, DA + TA + DB as Total  From TrainData  where CurrentStation != NextStation  Order BY Time;
-- Create Table Passenger Count
Create Table PassengerCount
(
	Sno INT IDENTITY(1,1) PRIMARY KEY,
	DDateTime DATETIME Not null,
	Trainno Varchar(10) Not null,
	Direction int Not null,
	Corridor int Not null,
	HeadControlDA int Not Null,
	HeadControlDB int Not Null,
	BoogieLoadDA1 int Not null,
	BoogieLoadDA2 int Not null,
	BoogieLoadTA1 int Not null,
	BoogieLoadTA2 int Not null,
	BoogieLoadDB1 int Not null,
	BoogieLoadDB2 int Not null,
	SpeedDA int Not null,
	SpeedDB int Not null,
	CurrentStationDA int not null,
	CurrentStationDB int not null,
	NextStationDA int not null,
	NextStationDB int not null,
	WriteTime DATETIME NOT NULL CONSTRAINT DF_PassengerCount_WriteTime DEFAULT (GETDATE())
);

Create Table MissingTrainsDataLog
(
	LogID INT IDENTITY(1,1) PRIMARY KEY,
	DDate Date Not Null,
	CheckUpToDate Date Not Null,
	ProcessedDateTime DateTime Null,
	MissingTrains VARCHAR(2000) Null,
	EmailSent BIT Not Null Default (0),
	EmailSentTime DateTime Null,
	Status TINYINT Not Null Default (0),
	WriteDateTime DATETIME NOT NULL CONSTRAINT
	DF_MissingTrainsDataLog DEFAULT (GETDATE())
);

CREATE TABLE StationCodes
(
StationCode int Not Null,
StationName Varchar(1000) Not Null,
StationSht Varchar(100) Not Null
);
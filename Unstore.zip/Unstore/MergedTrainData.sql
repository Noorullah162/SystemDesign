WITH TrainData1 AS (
    SELECT
        DISTINCT t.Time,
        (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 AS DA,
        (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 AS TA,
        (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 AS DB,
        t.HeadControl_DA,
        t.Speed_DA,
        sc_current_da.stationFullName AS CurrentStation,
        t.CurrentStation_DA as currentStationCode,
        sc_next_da.stationFullName AS NextStation1,
        t.NextStation_DA AS NextStation -- Added NextStation for Description1
    FROM TS005 t
    INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode
    INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode
    WHERE t.CurrentStation_DA != "" and
    t.Time BETWEEN '2025-02-20 15:07:55.5' and '2025-02-20 15:53:01.5'
    GROUP BY t.CurrentStation_DA, t.Time, sc_current_da.stationFullName, sc_next_da.stationFullName, t.NextStation_DA, t.HeadControl_DA, t.Speed_DA, t.BoogieLoad_DA1, t.BoogieLoad_DA2, t.BoogieLoad_TA1, t.BoogieLoad_TA2, t.BoogieLoad_DB1, t.BoogieLoad_DB2 -- Added missing columns in GROUP BY
),
Data1 AS ( -- Corrected: Changed "With" to "Data1 AS"
    SELECT
        ROW_NUMBER() OVER (ORDER BY Time) AS RowNumber1,
        CurrentStation AS CurrentStation1,
        CONCAT(Time, ' ', CurrentStation, ' - ', NextStation) AS Description1,
        DA AS DA1, -- Alias the calculated DA
        TA AS TA1, -- Alias the calculated TA
        DB AS DB1, -- Alias the calculated DB
        DA + TA + DB AS Total1
    FROM TrainData1
    WHERE CurrentStation != NextStation
    ORDER BY Time
),
TrainData2 AS ( -- Corrected: Changed "WITH" to "TrainData2 AS"
    SELECT
        DISTINCT t.Time,
        (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 AS DA,
        (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 AS TA,
        (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 AS DB,
        t.HeadControl_DA,
        t.Speed_DA,
        sc_current_da.stationFullName AS CurrentStation,
        t.CurrentStation_DA as currentStationCode,
        sc_next_da.stationFullName AS NextStation2,
        t.NextStation_DA AS NextStation -- Added NextStation for Description2
    FROM TS002 t
    INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode
    INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode
    WHERE t.CurrentStation_DA != "" and
    t.Time BETWEEN '2025-02-20 06:51:04.0' and '2025-02-20 07:38:10.5'
    GROUP BY t.CurrentStation_DA, t.Time, sc_current_da.stationFullName, sc_next_da.stationFullName, t.NextStation_DA, t.HeadControl_DA, t.Speed_DA, t.BoogieLoad_DA1, t.BoogieLoad_DA2, t.BoogieLoad_TA1, t.BoogieLoad_TA2, t.BoogieLoad_DB1, t.BoogieLoad_DB2 -- Added missing columns in GROUP BY
),
Data2 AS ( -- Corrected: Changed "With" to "Data2 AS"
SELECT
    ROW_NUMBER() OVER (ORDER BY Time) AS RowNumber2,
    CurrentStation AS CurrentStation2,
    CONCAT(Time, ' ', CurrentStation, ' - ', NextStation) AS Description2,
    DA AS DA2, -- Alias the calculated DA
    TA AS TA2, -- Alias the calculated TA
    DB AS DB2, -- Alias the calculated DB
    DA + TA + DB AS Total2
FROM TrainData2
WHERE CurrentStation != NextStation
ORDER BY Time
)

SELECT
    COALESCE(t1.RowNumber1, t2.RowNumber2) AS RowNumber, -- Corrected alias for row number
    t1.CurrentStation1,
    t1.Description1,
    t1.DA1,
    t1.TA1,
    t1.DB1,
    t1.Total1,
	t2.RowNumber2,
    t2.CurrentStation2,
    t2.Description2,
    t2.DA2,
    t2.TA2,
    t2.DB2,
    t2.Total2
FROM Data1 t1
FULL OUTER JOIN Data2 t2 ON t1.RowNumber1 = t2.RowNumber2;
select * from TS002;

-- Total Energy Consumption
SELECT StartTime, EndTime, TotalConsumed, RegeneratedEnergy, NetEnergy
FROM TS002
WHERE date(StartTime) >= '2024-12-01'
  AND date(StartTime) <= '2024-12-06';

-- better approach of date time track because of CTE
WITH ranked as (
select *, date(StartTime) as StartDate,
	row_number() OVER (
	Partition by date(startTime)
	order by StartTime asc) as rn_start,
	row_number() over (
	PARTITION by date(startTime)
	order by StartTime desc) as rn_end
	from TS005
	Where StartTime >= '2024-12-01' and date(starttime) <= '2024-12-14'
)
select StartTime, EndTime, TotalConsumed as Total_Con, RegeneratedEnergy as Reg_Eng, NetEnergy as Net_Eng from ranked where rn_start =1 or rn_end = 1 order by StartDate;

-- Traction Energy Consumption
SELECT	StartTime, EndTime, 
		SecondaryConsumedDACI1 as CI1, SecondaryRegeneratedDACI1 as CI1reg, 
		SecondaryConsumedDACI2 as CI2, SecondaryRegeneratedDACI2 as CI2reg,
		SecondaryConsumedDBCI3 as CI3, SecondaryRegeneratedDBCI3 as CI3reg,
		SecondaryConsumedDBCI4 as CI4, SecondaryRegeneratedDBCI4 as CI4reg,
		SecondaryConsumedDACI1 + SecondaryRegeneratedDACI1 + SecondaryConsumedDACI2 + SecondaryRegeneratedDACI2 +
		SecondaryConsumedDBCI3 + SecondaryRegeneratedDBCI3 + SecondaryConsumedDBCI4 + SecondaryRegeneratedDBCI4 as Total
FROM TS002
WHERE date(StartTime) >= '2025-01-05'
  AND date(StartTime) <= '2025-01-11';

WITH ranked as (
select *, date(StartTime) as onlydate,
	row_number() OVER (
	Partition by date(startTime)
	order by StartTime asc) as rn_start,
	row_number() over (
	PARTITION by date(startTime)
	order by StartTime desc) as rn_end
	from TS002
	Where StartTime >= '2025-01-05' and date(starttime) <= '2025-01-11'
)
select  StartTime, EndTime, 
		SecondaryConsumedDACI1 as CI1_Con, SecondaryRegeneratedDACI1 as CI1_Reg,
		SecondaryConsumedDACI2 as CI2_Con, SecondaryRegeneratedDACI2 as CI2_Reg,
		SecondaryConsumedDBCI3 as CI3_Con, SecondaryRegeneratedDBCI3 as CI3_Reg,
		SecondaryConsumedDBCI4 as CI4_Con, SecondaryRegeneratedDBCI4 as CI4_Reg,
		SecondaryConsumedDACI1 + SecondaryRegeneratedDACI1 + SecondaryConsumedDACI2 + SecondaryRegeneratedDACI2 +
		SecondaryConsumedDBCI3 + SecondaryRegeneratedDBCI3 + SecondaryConsumedDBCI4 + SecondaryRegeneratedDBCI4 as Total 
from ranked where rn_start =1 or rn_end = 1 order by onlydate;

-- HVAC Energy Consumption
SELECT	StartTime, EndTime, 
		SecondaryNetVac1 as HVAC1, SecondaryNetVac2 as HVAC2, 
		SecondaryNetVac3 as HVAC3, SecondaryNetVac4 as HVAC4,
		SecondaryNetVac5 as HVAC5, SecondaryNetVac6 as HVAC6,
		SecondaryNetVac1 + SecondaryNetVac2 + SecondaryNetVac3 +
		SecondaryNetVac4 + SecondaryNetVac5 + SecondaryNetVac6 as Total
FROM TS002
WHERE date(StartTime) >= '2025-01-05'
  AND date(StartTime) <= '2025-01-11';
  
WITH ranked as (
select *, date(StartTime) as StartDate,
	row_number() OVER (
	Partition by date(startTime)
	order by StartTime asc) as rn_start,
	row_number() over (
	PARTITION by date(startTime)
	order by StartTime desc) as rn_end
	from TS002
	Where StartTime >= '2024-12-01' and date(starttime) <= '2024-12-31'
)
select StartTime, EndTime, 
		SecondaryNetVac1 as HVAC_1, SecondaryNetVac2 as HVAC_2, 
		SecondaryNetVac3 as HVAC_3, SecondaryNetVac4 as HVAC_4,
		SecondaryNetVac5 as HVAC_5, SecondaryNetVac6 as HVAC_6,
		SecondaryNetVac1 + SecondaryNetVac2 + SecondaryNetVac3 +
		SecondaryNetVac4 + SecondaryNetVac5 + SecondaryNetVac6 as Total_HVAC
from ranked where rn_start =1 or rn_end = 1 order by StartDate;



-- APS Energy Consumption
SELECT	DISTINCT StartTime, EndTime, 
		SecondaryNetDA_APSMotoring + SecondaryNetDA_APSBraking as APS_1, 
		SecondaryNetDB_APSMotoring + SecondaryNetDB_APSBraking as APS_2,
		SecondaryNetDA_APSMotoring + SecondaryNetDA_APSBraking + SecondaryNetDB_APSMotoring + SecondaryNetDB_APSBraking  as Total_APS
FROM TS002
WHERE date(StartTime) >= '2025-01-05'
  AND date(StartTime) <= '2025-01-11' order by StartTime;
  
WITH ranked as (
select *, date(StartTime) as day,
	strftime('%y-%m', starttime) as ym,
	(strftime('%s', endtime) - strftime('%s', starttime)) as duration,
	row_number() OVER (
	Partition by date(startTime)
	order by duration desc) as rn,
	from TS002
	Where StartTime) >= '2024-01-01' and date(starttime) <= '2025-01-11'
)
select StartTime, EndTime, 
		SecondaryNetDA_APSMotoring + SecondaryNetDA_APSBraking as APS_1, 
		SecondaryNetDB_APSMotoring + SecondaryNetDB_APSBraking as APS_2,
		SecondaryNetDA_APSMotoring + SecondaryNetDA_APSBraking + SecondaryNetDB_APSMotoring + SecondaryNetDB_APSBraking  as Total_APS
from ranked where rn_start =1 or rn_end = 1 order by StartDate;



WITH ranked as (
select *, date(StartTime) as day,
	strftime('%y-%m', starttime) as ym,
	(strftime('%s', endtime) - strftime('%s', starttime)) as duration,
	row_number() OVER (
	Partition by date(startTime)
	order by strftime('%s', endtime) - strftime('%s', starttime) desc) as rn
	from TS002
	Where StartTime >= '2024-01-01' and starttime < '2025-01-01'
)
select  substr(ym, 1, 4) as year, 
		substr(ym, 6, 2) as month,
		sum(TotalConsumed) as Total_Con, 
		sum(RegeneratedEnergy) as Reg_Eng, 
		sum(NetEnergy) as Net_Eng 
from ranked 
where rn = 1
group by ym;




  

  
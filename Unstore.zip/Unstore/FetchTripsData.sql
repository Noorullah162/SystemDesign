
select 
row_number() over (order by DDatetime) as Sno, 
cs.StationName as Station, 
Concat(Convert(Varchar(100), t.DDatetime, 120), ' ', cs.StationName, ' - ', ns.StationName ) as TimeOfArrival, 
(BoogieLoadDA1 + t.BoogieLoadDA2  - 42590) / 65  AS DA , 
(t.BoogieLoadTA1 + t.BoogieLoadTA2 - 39980) / 65 AS TA, 
(t.BoogieLoadDB1  + t.BoogieLoadDB2  - 42590) / 65 AS DB, 
((BoogieLoadDA1 + t.BoogieLoadDA2  - 42590) / 65) +  
((t.BoogieLoadTA1 + t.BoogieLoadTA2 - 39980) / 65) + 
((t.BoogieLoadDB1  + t.BoogieLoadDB2  - 42590) / 65)  as Total 
FROM PassengerCount t 
Inner Join StationCodes as cs on t.CurrentStationDA = cs.StationCode 
Inner Join StationCodes as ns on t.NextStationDA = ns.StationCode 
WHERE t.DDateTime >= '2026-06-08 07:47:28.500' and t.DDateTime <= '2026-06-08 08:32:19.000' 
and Trainno = 'TS002';
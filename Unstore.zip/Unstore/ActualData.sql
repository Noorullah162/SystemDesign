SELECT
    t.Time,
    (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 AS DA,
    (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 AS TA,
    (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 AS DB,
    (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 +
    (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 +
    (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 AS Total,
    t.HeadControl_DA,
    t.Speed_DA,
    sc_current_da.stationFullName AS CurrentStation_DA_Name,
	t.CurrentStation_DA,
    sc_next_da.stationFullName AS NextStation_DA_Name,
	t.NextStation_DA,
    t.HeadControl_DB,
    t.Speed_DA,
    t.CurrentStation_DB,
    t.NextStation_DB
FROM TS005 t
LEFT JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode
LEFT JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode
WHERE t.CurrentStation_DA != "" 
and
t.Time = '2025-08-12 07:38:47.5' 
-- t.Time BETWEEN '2025-02-20 07:43:15.0' and '2025-02-20 08:28:22.0'
GROUP BY t.Time
ORDER BY t.Time;
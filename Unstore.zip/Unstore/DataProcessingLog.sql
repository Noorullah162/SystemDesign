CREATE TABLE DataProcessingLog (
    LogID INTEGER PRIMARY KEY AUTOINCREMENT,
    DataDate VARCHAR(100) NOT NULL, -- ISO 8601 format (e.g., '2025-05-27')
    MissingDataDateCheck VARCHAR(100) NOT NULL,
	ProcessedDateTime VARCHAR(100) NOT NULL, -- ISO 8601 format
    MissingTrains VARCHAR(10000), -- Comma-separated TrainIDs (e.g., '3,15,27')
    Status INTEGER NOT NULL CHECK(Status IN (-1, 0, 1)), -- 'Partial', 'Complete', 'Failed'
	EmailSent VARCHAR(100) NOT NULL DEFAULT 0, -- 0 = false, 1 = true
    EmailSentDateTime VARCHAR(100) -- ISO 8601 format or NULL
    
);

CREATE INDEX idx_DataProcessingLog_Date ON DataProcessingLog(DataDate);


INSERT into DataProcessingLog ( DataDate, MissingDataDateCheck, ProcessedDateTime, MissingTrains, Status, EmailSent, EmailSentDateTime)
VALUES ( "2024-12-10", "2025-06-30", "2024-12-10 11:04", "002, 003", 0, "1", "2024-12-10 11:04");

select * from DataProcessingLog;

SELECT * FROM DataProcessingLog WHERE MissingDataDateCheck = '2025-06-30' AND Status = 0 AND MissingTrains IS NOT NULL AND MissingTrains != '' ORDER BY DataDate DESC;

Trucate table DataProcessingLog;
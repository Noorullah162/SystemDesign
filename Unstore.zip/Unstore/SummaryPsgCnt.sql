WITH TripData AS ( 
    SELECT 
        DDateTime,  
        Direction,
        Trainno,
        CASE WHEN Direction != LAG(Direction) OVER(ORDER BY Trainno, DDateTime) THEN 1 ELSE 0 END AS trip_change  
    FROM PassengerCount 
    WHERE DDateTime >= '2026-06-08 00:00:00' AND DDateTime <= '2026-06-08 23:59:59' 
),

NumberedTrips AS ( 
    SELECT 
        *,
        SUM(trip_change) OVER(ORDER BY Trainno, DDateTime) AS trip_id 
    FROM TripData
)
SELECT 
    Trainno,
    Direction, 
    MIN(DDateTime) AS From_Datetime, 
    MAX(DDateTime) AS To_Datetime 
FROM NumberedTrips 
GROUP BY trip_id, Trainno, Direction
ORDER BY Trainno, From_Datetime;
use RTD;

select top 1 * from tAMS_EnergyMileage_DAILY where TrainNo = '002' and convert( Date, SDate ) = '2025-01-08' order by EDate;



select * from tAMS_EnergyMileage_DAILY where TrainNo = '004' and convert( Date, SDate ) = '2024-10-14';

select * from tAMS_EnergyMileage_DAILY where TrainNo = '005' and convert( Date, SDate ) = '2024-10-14';

select * from tAMS_EnergyMileage_DAILY where TrainNo = '006' and convert( Date, SDate ) = '2024-10-14';

select * from tAMS_EnergyMileage_DAILY where TrainNo = '007' and convert( Date, SDate ) = '2024-10-14';

select  Sum(meterid_DA_DSecAPC + meterid_DB_DSecAPC) from tAMS_EnergyMileage_DAILY where (TrainNo = '004' or TrainNo = '005' or TrainNo = '006' 
or TrainNo = '007') and Convert(Date, SDate) = '2024-12-14' and convert(Date, EDate) >= '2024-12-14';
WITH TripData AS ( 
SELECT no,  time,  HeadControl_DA, 
CASE WHEN HeadControl_DA != LAG(HeadControl_DA) OVER(ORDER BY time) THEN 1 ELSE 0 END AS trip_change 
FROM TS003 WHERE DATE(time) = '2025-01-13' ),
NumberedTrips AS( SELECT *, SUM(trip_change) OVER(ORDER BY time) AS trip_id FROM TripData) 
 SELECT CASE WHEN HeadControl_DA = 1 THEN 'Upline' ELSE 'Downline' END AS Direction,
 MIN(time) AS From_Datetime, MAX(time) AS To_Datetime FROM NumberedTrips GROUP BY HeadControl_DA, trip_id ORDER BY From_Datetime;
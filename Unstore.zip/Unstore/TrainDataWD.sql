WITH TrainData AS (
    SELECT
        DISTINCT t.Time,
        (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 AS DA,
        (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 AS TA,
        (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 AS DB,
        t.HeadControl_DA,
        t.Speed_DA,
        sc.stationFullName AS current_station,
        t.NextStation_DA,
        t.HeadControl_DB,
        t.Speed_DA,
        t.NextStation_DB,
        LEAD(sc.stationFullName) OVER (ORDER BY t.Time) AS next_station,
        LEAD(t.Time) OVER (ORDER BY t.Time) AS next_time
    FROM TS001 t
    INNER JOIN MetroTrainHyderabadStationCodes sc ON t.NextStation_DA = sc.stationCode
    WHERE 
	t.time >= "2025-08-12 08:05:55.0" AND t.time <= "2025-08-12 08:54:52.0"
	
)
SELECT 
	row_number() over (Order by time) as RowNumber,
	current_station,
    -- Generate the description column
    CASE 
        WHEN next_station IS NOT NULL THEN CONCAT(Time, ' ', current_station, ' - ', next_station)
        ELSE CONCAT(Time, ' ', current_station) 
    END AS Description,
	DA,
	TA,
	DB,
	Total
FROM TrainData
ORDER BY Time;



WITH TrainData AS 
(   SELECT DISTINCT t.Time,  
CASE When (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 <= 0 THEN 0 
ELSE  (IFNULL(CAST(t.BoogieLoad_DA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DA2 AS INTEGER), 0) - 42590) / 65 End AS DA,  
CASE when (IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 <= 0 THEN 0 Else  
(IFNULL(CAST(t.BoogieLoad_TA1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_TA2 AS INTEGER), 0) - 39980) / 65 End AS TA,  
CASE when (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 <= 0 
THEN 0 Else (IFNULL(CAST(t.BoogieLoad_DB1 AS INTEGER), 0) + IFNULL(CAST(t.BoogieLoad_DB2 AS INTEGER), 0) - 42590) / 65 End  AS DB,  
t.HeadControl_DA, t.Speed_DA, sc_current_da.stationFullName AS CurrentStation, sc_next_da.stationFullName AS NextStation 
FROM TS003 as t  
INNER JOIN MetroTrainHyderabadStationCodes sc_current_da ON t.CurrentStation_DA = sc_current_da.stationCode  
INNER JOIN MetroTrainHyderabadStationCodes sc_next_da ON t.NextStation_DA = sc_next_da.stationCode 
 WHERE t.CurrentStation_DA != '' and  t.time Between '2025-08-12 08:05:55.0' AND '2025-08-12 08:54:52.0'  GROUP by t.CurrentStation_DA  ) 
 SELECT    row_number() OVER (ORDER BY Time) AS SNo, CurrentStation as Station,  
 CASE  WHEN CurrentStation IS NOT NULL AND LENGTH(CurrentStation) > 0 THEN Time || ' ' || CurrentStation || ' - ' || NextStation  ELSE ' '  END AS TimeofArrival,  DA, TA, DB, DA + TA + DB as Total,  
 NTILE(3) OVER (ORDER BY DA+TA+DB ) - 1 AS Status From TrainData  where CurrentStation != NextStation  Order BY Time;
namespace PassengerGraph.Models
{
    public class PassengerGraphPoint
    {
        public string TrainNo { get; set; }
        public int TripId { get; set; }
        public int StationIndex { get; set; }
        public string CurrentStation { get; set; }
        public string NextStation { get; set; }
        public System.DateTime DDateTime { get; set; }
        public int TotalPassenger { get; set; }
    }
}

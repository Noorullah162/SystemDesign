using LiveChartsCore.Defaults;
namespace PassengerGraph.Models
{
    public class PassengerChartPoint : ObservablePoint
    {
        public string TrainNo { get; set; }
        public int TripId { get; set; }
        public int StationIndex { get; set; }
        public System.DateTime DDateTime { get; set; }
        public string CurrentStation { get; set; }
        public string NextStation { get; set; }
        public int PassengerCount { get; set; }
    }
}

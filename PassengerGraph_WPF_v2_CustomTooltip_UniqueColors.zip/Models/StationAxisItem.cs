namespace PassengerGraph.Models
{
    public class StationAxisItem
    {
        public int StationIndex { get; set; }
        public string StationName { get; set; }
    }
}

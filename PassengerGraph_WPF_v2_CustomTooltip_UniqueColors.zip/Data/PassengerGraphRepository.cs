using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using PassengerGraph.Models;

namespace PassengerGraph.Data
{
    public class PassengerGraphRepository
    {
        private readonly string _connectionString;
        public PassengerGraphRepository(string connectionString) { _connectionString = connectionString; }

        public async Task<List<PassengerGraphPoint>> GetPassengerGraphDataAsync(
            DateTime from, DateTime to, int corridor, int direction,
            CancellationToken token = default(CancellationToken))
        {
            var list = new List<PassengerGraphPoint>();
            const string sql = @"
;WITH TripData AS
(
 SELECT p.*,
 CASE WHEN LAG(p.Direction) OVER(PARTITION BY p.TrainNo,p.Corridor ORDER BY p.DDateTime)<>p.Direction THEN 1 ELSE 0 END TripChange
 FROM PassengerCount p
 WHERE p.DDateTime>=CAST(@From AS DATE)
 AND p.DDateTime<DATEADD(DAY,1,CAST(@From AS DATE))
 AND p.Corridor=@Corridor
),
NumberedTrips AS
(
 SELECT *,SUM(TripChange) OVER(PARTITION BY TrainNo,Corridor ORDER BY DDateTime ROWS UNBOUNDED PRECEDING) TripId
 FROM TripData
),
PassengerData AS
(
 SELECT TrainNo,TripId,Direction,Corridor,DDateTime,CurrentStationDA,NextStationDA,
 CAST((BoogieLoadDA1+BoogieLoadDA2-42590)/65 AS INT) DA,
 CAST((BoogieLoadTA1+BoogieLoadTA2-39980)/65 AS INT) TA,
 CAST((BoogieLoadDB1+BoogieLoadDB2-42590)/65 AS INT) DB
 FROM NumberedTrips
 WHERE DDateTime>=@From AND DDateTime<@To
 AND Direction=@Direction AND CurrentStationDA<>NextStationDA
),
StationData AS
(
 SELECT p.TrainNo,p.TripId,cds.StationIndex,p.DDateTime,
 cs.StationName CurrentStation,ns.StationName NextStation,
 CASE WHEN p.DA<0 THEN 0 ELSE p.DA END+
 CASE WHEN p.TA<0 THEN 0 ELSE p.TA END+
 CASE WHEN p.DB<0 THEN 0 ELSE p.DB END TotalPassenger
 FROM PassengerData p
 INNER JOIN CorridorDirectionStations cds
 ON cds.Corridor=p.Corridor AND cds.Direction=p.Direction
 AND cds.StationCode=p.CurrentStationDA
 INNER JOIN StationCodes cs ON cs.StationCode=p.CurrentStationDA
 INNER JOIN StationCodes ns ON ns.StationCode=p.NextStationDA
),
FinalData AS
(
 SELECT *,ROW_NUMBER() OVER(PARTITION BY TrainNo,TripId,StationIndex ORDER BY DDateTime) rn
 FROM StationData
)
SELECT TrainNo,TripId,StationIndex,CurrentStation,NextStation,DDateTime,TotalPassenger
FROM FinalData WHERE rn=1 ORDER BY StationIndex,TrainNo,DDateTime;";

            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.CommandTimeout = 120;
                cmd.Parameters.AddWithValue("@From", from);
                cmd.Parameters.AddWithValue("@To", to);
                cmd.Parameters.AddWithValue("@Corridor", corridor);
                cmd.Parameters.AddWithValue("@Direction", direction);
                await cn.OpenAsync(token).ConfigureAwait(false);
                using (var r = await cmd.ExecuteReaderAsync(token).ConfigureAwait(false))
                    while (await r.ReadAsync(token).ConfigureAwait(false))
                        list.Add(new PassengerGraphPoint {
                            TrainNo=r["TrainNo"].ToString(),
                            TripId=Convert.ToInt32(r["TripId"]),
                            StationIndex=Convert.ToInt32(r["StationIndex"]),
                            CurrentStation=r["CurrentStation"].ToString(),
                            NextStation=r["NextStation"].ToString(),
                            DDateTime=Convert.ToDateTime(r["DDateTime"]),
                            TotalPassenger=Convert.ToInt32(r["TotalPassenger"])
                        });
            }
            return list;
        }

        public async Task<List<StationAxisItem>> GetStationAxisAsync(
            int corridor, int direction,
            CancellationToken token = default(CancellationToken))
        {
            var list = new List<StationAxisItem>();
            const string sql = @"SELECT cds.StationIndex,sc.StationName
FROM CorridorDirectionStations cds
INNER JOIN StationCodes sc ON sc.StationCode=cds.StationCode
WHERE cds.Corridor=@Corridor AND cds.Direction=@Direction
ORDER BY cds.StationIndex;";

            using (var cn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, cn))
            {
                cmd.Parameters.AddWithValue("@Corridor", corridor);
                cmd.Parameters.AddWithValue("@Direction", direction);
                await cn.OpenAsync(token).ConfigureAwait(false);
                using (var r = await cmd.ExecuteReaderAsync(token).ConfigureAwait(false))
                    while (await r.ReadAsync(token).ConfigureAwait(false))
                        list.Add(new StationAxisItem {
                            StationIndex=Convert.ToInt32(r["StationIndex"]),
                            StationName=r["StationName"].ToString()
                        });
            }
            return list;
        }
    }
}

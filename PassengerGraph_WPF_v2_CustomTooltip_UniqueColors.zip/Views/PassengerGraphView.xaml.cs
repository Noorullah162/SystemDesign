using System.Windows;
using System.Windows.Controls;
using PassengerGraph.ViewModels;

namespace PassengerGraph.Views
{
    public partial class PassengerGraphView : UserControl
    {
        public PassengerGraphView()
        {
            InitializeComponent();

            var connectionString =
                "Server=YOUR_SERVER;Database=YOUR_DATABASE;Trusted_Connection=True;";

            DataContext = new PassengerGraphViewModel(connectionString);
            Loaded += async (s,e) =>
            {
                var vm = DataContext as PassengerGraphViewModel;
                if (vm != null) await vm.LoadAsync();
            };
            Unloaded += (s,e) =>
            {
                var vm = DataContext as PassengerGraphViewModel;
                if (vm != null) vm.Dispose();
            };
        }

        private async void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as PassengerGraphViewModel;
            if (vm != null) await vm.LoadAsync();
        }
    }
}

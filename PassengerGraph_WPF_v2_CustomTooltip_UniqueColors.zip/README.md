# Passenger Graph V2

This version fixes the two issues you reported:

1. Default LiveCharts colors were repeating for 22 trips.
2. Tooltip did not contain the exact point's date/time and station information.

## Important changes

### Unique colors
The ViewModel explicitly assigns a 30-color palette. Therefore 22 train/trip lines get 22 different colors instead of relying on LiveCharts' repeating default palette.

### Exact tooltip data
`PassengerChartPoint` inherits from `ObservablePoint`, so it still has X/Y for LiveCharts but also keeps:

- TrainNo
- TripId
- StationIndex
- DDateTime
- CurrentStation
- NextStation
- PassengerCount

The tooltip displays:

Train: TS012 / Trip 1
Time: 08-06-2026 07:12:13.500
HITEC City -> Durgam Cheruvu
Passenger Count: 90

### Hover behaviour
The chart uses:

FindingStrategy="ExactMatchTakeClosest"

This is intended to select the point whose drawn shape is actually under/closest to the pointer rather than selecting every train at the same station/X coordinate.

The point marker is also increased to 9 so individual points are easier to hover.

## Static test
Corridor = 3
Direction = 1
From = 2026-06-08 07:00
To = 2026-06-08 09:00

## Copy into your existing WPF .NET Framework 4.8.1 project

Models:
- PassengerChartPoint.cs
- PassengerGraphPoint.cs
- StationAxisItem.cs

ViewModels:
- PassengerGraphViewModel.cs

Views:
- PassengerGraphView.xaml
- PassengerGraphView.xaml.cs

Keep your existing repository/data layer if you already have one; move the SQL/data method into it rather than creating a second data layer.

Replace the sample connection string with your existing SQL connection string.

## LiveCharts version
The code uses the LiveCharts2 API style. If `FindingStrategy="ExactMatchTakeClosest"` or `LineSeries<PassengerChartPoint>` gives a compile error, send me the exact LiveCharts NuGet package versions from your project. LiveCharts2 has changed some APIs between RC versions.

## Next step
After this works, we should add:
1. Highlight the entire hovered train line.
2. Fade all other lines while hovering.
3. Highlight the exact hovered point.
4. Automatic hiding/disable of inactive trains.
5. Station active/inactive behaviour.
6. 1-hour/2-hour filters.
7. Automatic refresh.

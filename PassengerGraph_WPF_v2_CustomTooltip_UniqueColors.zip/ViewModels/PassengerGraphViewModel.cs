using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using PassengerGraph.Data;
using PassengerGraph.Models;
using SkiaSharp;

namespace PassengerGraph.ViewModels
{
    public class PassengerGraphViewModel : INotifyPropertyChanged
    {
        private readonly PassengerGraphRepository _repository;
        private CancellationTokenSource _cts;

        public int Corridor { get; set; } = 3;
        public int Direction { get; set; } = 1;
        public DateTime FromDateTime { get; set; } =
            new DateTime(2026, 6, 8, 7, 0, 0);
        public DateTime ToDateTime { get; set; } =
            new DateTime(2026, 6, 8, 9, 0, 0);

        public ISeries[] Series { get; private set; } = new ISeries[0];
        public Axis[] XAxes { get; private set; } = new Axis[0];
        public Axis[] YAxes { get; } =
        {
            new Axis { Name = "Passenger Count", Labeler = v => v.ToString("0") }
        };
        public string Status { get; private set; } = "Ready";

        public event PropertyChangedEventHandler PropertyChanged;

        public PassengerGraphViewModel(string connectionString)
        {
            _repository = new PassengerGraphRepository(connectionString);
        }

        public async Task LoadAsync()
        {
            _cts?.Cancel();
            _cts?.Dispose();
            _cts = new CancellationTokenSource();

            try
            {
                Status = "Loading...";
                OnPropertyChanged(nameof(Status));

                var stationsTask = _repository.GetStationAxisAsync(
                    Corridor, Direction, _cts.Token);

                var dataTask = _repository.GetPassengerGraphDataAsync(
                    FromDateTime, ToDateTime, Corridor, Direction, _cts.Token);

                await Task.WhenAll(stationsTask, dataTask);

                var stations = await stationsTask;
                var data = await dataTask;

                XAxes = new[]
                {
                    new Axis
                    {
                        Name = "Stations",
                        Labels = stations.OrderBy(x => x.StationIndex)
                            .Select(x => x.StationName).ToArray(),
                        LabelsRotation = 45
                    }
                };

                var palette = GetPalette();
                var groups = data.GroupBy(x => new { x.TrainNo, x.TripId })
                    .OrderBy(g => g.Min(x => x.StationIndex))
                    .ThenBy(g => g.Key.TrainNo)
                    .ThenBy(g => g.Key.TripId)
                    .ToList();

                var result = new List<ISeries>();

                for (int i = 0; i < groups.Count; i++)
                {
                    var g = groups[i];

                    var values = g.OrderBy(x => x.StationIndex)
                        .ThenBy(x => x.DDateTime)
                        .Select(x => new PassengerChartPoint
                        {
                            X = x.StationIndex - 1,
                            Y = x.TotalPassenger,
                            TrainNo = x.TrainNo,
                            TripId = x.TripId,
                            StationIndex = x.StationIndex,
                            DDateTime = x.DDateTime,
                            CurrentStation = x.CurrentStation,
                            NextStation = x.NextStation,
                            PassengerCount = x.TotalPassenger
                        }).ToArray();

                    var color = palette[i % palette.Count];

                    result.Add(new LineSeries<PassengerChartPoint>
                    {
                        Name = g.Key.TrainNo + " / Trip " + g.Key.TripId,
                        Values = values,
                        Stroke = new SolidColorPaint(color, 3),
                        Fill = null,
                        GeometrySize = 9,
                        LineSmoothness = 0,
                        IsHoverable = true,
                        TooltipLabelFormatter = cp =>
                        {
                            var p = cp.Model;
                            return p == null ? "" :
                                string.Format(
                                    "Train: {0} / Trip {1}\nTime: {2:dd-MM-yyyy HH:mm:ss.fff}\n{3} → {4}\nPassenger Count: {5}",
                                    p.TrainNo, p.TripId, p.DDateTime,
                                    p.CurrentStation, p.NextStation,
                                    p.PassengerCount);
                        }
                    });
                }

                Series = result.ToArray();
                Status = groups.Count + " train/trip lines, " +
                         data.Count + " points loaded.";

                OnPropertyChanged(nameof(XAxes));
                OnPropertyChanged(nameof(Series));
                OnPropertyChanged(nameof(Status));
            }
            catch (OperationCanceledException)
            {
                Status = "Refresh cancelled.";
                OnPropertyChanged(nameof(Status));
            }
            catch (Exception ex)
            {
                Status = "Error: " + ex.Message;
                OnPropertyChanged(nameof(Status));
            }
        }

        private List<SKColor> GetPalette()
        {
            return new List<SKColor>
            {
                new SKColor(31,119,180), new SKColor(255,127,14),
                new SKColor(44,160,44), new SKColor(214,39,40),
                new SKColor(148,103,189), new SKColor(140,86,75),
                new SKColor(227,119,194), new SKColor(127,127,127),
                new SKColor(188,189,34), new SKColor(23,190,207),
                new SKColor(0,102,204), new SKColor(230,85,13),
                new SKColor(49,130,189), new SKColor(166,54,3),
                new SKColor(117,107,177), new SKColor(35,139,69),
                new SKColor(189,0,38), new SKColor(0,109,44),
                new SKColor(217,95,14), new SKColor(123,50,148),
                new SKColor(255,20,147), new SKColor(0,128,128),
                new SKColor(128,0,0), new SKColor(0,0,128),
                new SKColor(85,107,47), new SKColor(139,69,19),
                new SKColor(75,0,130), new SKColor(0,139,139),
                new SKColor(218,112,214), new SKColor(70,130,180)
            };
        }

        public void Dispose() { _cts?.Cancel(); _cts?.Dispose(); }

        private void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}

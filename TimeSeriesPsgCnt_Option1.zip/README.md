# TimeSeriesPsgCntView - Option 1

Files included:
- TimeSeriesPsgCntView.xaml
- TimeSeriesPsgCntView.xaml.cs
- TimeSeriesPsgCntViewModel.cs

UI approach:
- Keeps Date/Time, Corridor, Direction and Apply Filter visually together.
- Keeps Stations and Train Lines as chart controls directly above the graph.
- Keeps the train legend on the right to protect graph width and handle many train/trip series.
- Legend items show line color/geometry, train number, start time and starting station.
- Uses the existing WPFUI SymbolIcon, WPF controls, LiveCharts2 and SkiaSharp approach.
- Station and train selection remain client-side visibility filters after data is loaded.

Important implementation note:
- The legend uses a small ViewModel-only TimeSeriesLegendItem class so the provided code does not require an unknown change to the existing LineSeriesLegends model definition.
- The graph line Stroke is now assigned from the existing palette so the legend color matches the chart line.

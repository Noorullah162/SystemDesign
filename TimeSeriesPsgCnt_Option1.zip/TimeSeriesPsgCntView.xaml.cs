using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TIMSDataInsights.CustomDataTypes.Enums;
using TIMSDataInsights.UserControls;
using TIMSDataInsights.ViewModels;

namespace TIMSDataInsights.Views
{
    /// <summary>
    /// Interaction logic for TimeSeriesPsgCntView.xaml
    /// </summary>
    public partial class TimeSeriesPsgCntView : Page
    {
        private TimeSeriesPsgCntViewModel TimeSeriesPsgCntViewModelRef = null;

        public TimeSeriesPsgCntView()
        {
            InitializeComponent();

            TimeSeriesPsgCntViewModelRef = new TimeSeriesPsgCntViewModel();
            DataContext = TimeSeriesPsgCntViewModelRef;

            TimeSeriesPsgCntViewModelRef.DisplayDateTimeSpanWindow += DisplayDateTimeSpanWindow;
        }

        private void DisplayDateTimeSpanWindow()
        {
            DateTimeSpan dateTimeSpan = new DateTimeSpan(
                TimeSeriesPsgCntViewModelRef.FromDateTime,
                TimeSeriesPsgCntViewModelRef.ToDateTime)
            {
                Owner = ((App)System.Windows.Application.Current).MainWindow
            };

            dateTimeSpan.ShowDialog();

            switch (dateTimeSpan.Response)
            {
                case DateTimeSpanDialogResponse.Ok:
                    UpdateData(dateTimeSpan);
                    break;

                case DateTimeSpanDialogResponse.Cancle:
                    break;
            }
        }

        private void UpdateData(DateTimeSpan dateTimeSpan)
        {
            TimeSeriesPsgCntViewModelRef.FromDateTime = dateTimeSpan.FromDate;
            TimeSeriesPsgCntViewModelRef.ToDateTime = dateTimeSpan.ToDate;
        }
    }
}
